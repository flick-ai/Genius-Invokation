from .base import TalentCard
from .talents import *